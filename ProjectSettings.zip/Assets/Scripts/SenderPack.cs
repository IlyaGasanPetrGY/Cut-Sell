using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SenderPack : MonoBehaviour
{
    [SerializeField, Range(1,10)] private float _speedPack = 2;
    private static Transform _positionHouse;
    public static Transform PositionHouse
    {
        set
        {
            _positionHouse = value;
        }
    }
    private void Start()
    {
        transform.parent = null;
        StartCoroutine(Moving());
    }
    private IEnumerator Moving()
    {
        
        while (Vector3.Distance(transform.position, _positionHouse.position) > 0.01f)
        {
            transform.position = Vector3.MoveTowards(transform.position, _positionHouse.position, Time.deltaTime *  _speedPack);
            yield return new WaitForSeconds(0.001f);
        }
        Destroy(gameObject);
        HouseController.Housecontroller.SpawnCoins();
    }
}
