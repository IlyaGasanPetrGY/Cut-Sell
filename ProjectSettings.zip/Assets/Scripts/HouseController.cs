using UnityEngine;

public abstract class Houses: MonoBehaviour
{
    public abstract void GettingGrowedGrass();
    public abstract void SendMoney();
} 
public class HouseController : Houses
{
    [SerializeField] private GameObject _uiCoins;
    [SerializeField] private GameObject _prefabCoin;
    
    public static HouseController Housecontroller;

    private void Start()
    {
        SenderPack.PositionHouse = transform;
        Housecontroller = GetComponent<HouseController>();
    }
    public override void GettingGrowedGrass()
    {
        throw new System.NotImplementedException();
    }

    public override void SendMoney()
    {
        throw new System.NotImplementedException();
    }

    private void OnTriggerEnter(Collider other)
    {
        MovingPlayer _movingPlayer;
        if (other.TryGetComponent<MovingPlayer>(out _movingPlayer))
        {
            _movingPlayer.StartSending();
        }
    }
    public void SpawnCoins()
    {
        Instantiate(_prefabCoin, transform);
    }
}
