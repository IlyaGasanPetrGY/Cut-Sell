using System.Collections;
using UnityEngine;

public abstract class Vegetation:MonoBehaviour
{
    public abstract IEnumerator Grovving(float timeReload);
    public abstract void Slice();
    
}
public class Grasscontroller : Vegetation
{
    [SerializeField] private GameObject _readyGrass;
    [SerializeField] private GameObject _killedGrass;
    [SerializeField] private GameObject _controllableObject;
    [SerializeField] private GameObject _packGrass;
    [SerializeField] private float _timeToGrowGrass = 10f;
    private bool _statusGrass = true;

    public override IEnumerator Grovving(float timeReload)
    {
        yield return new WaitForSeconds(3f);
        Destroy(_controllableObject);
        _controllableObject = _killedGrass;
        _controllableObject = Instantiate(_controllableObject, transform);
        Instantiate(_packGrass, transform);
        _statusGrass = false;

        yield return new WaitForSeconds(10f);
        Destroy(_controllableObject);
        _controllableObject = _readyGrass;
        _controllableObject = Instantiate(_controllableObject,transform);
        _statusGrass = true;
    }

    public override void Slice()
    {
        StartCoroutine(Grovving(_timeToGrowGrass));     
    }


    private void OnTriggerEnter(Collider other)
    {
        MovingPlayer _movingPlayer;

        if (other.TryGetComponent<MovingPlayer>(out _movingPlayer) && _statusGrass)
        {
            other.transform.LookAt(transform);
            _movingPlayer.AnimationAtack();
            Slice();
        }
    }
}
