using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;


public class MarkerController : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
{
    [SerializeField] private Image _mark;

    private Vector3 _defultPositionMark;
    private Vector2 _startPositionMark;
    private Vector2 _directionfor;
    private Vector2 _dirctionForMovvingPlayer;
    public Vector2 DirctionForMovvingPlayer {
        get
        {
            return _dirctionForMovvingPlayer;
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        _startPositionMark = eventData.position;
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        _mark.transform.position = _mark.transform.parent.transform.position;
        _dirctionForMovvingPlayer = new Vector2(0,0);
    }
    public void OnDrag(PointerEventData eventData)
    {
        _directionfor = new Vector2(-Mathf.Clamp(_startPositionMark.x - eventData.position.x, -70, 70),- Mathf.Clamp(_startPositionMark.y - eventData.position.y, -70, 70));

        if (_directionfor.magnitude > 70)
        {
            _directionfor = new Vector2(_directionfor.normalized.x * 70, _directionfor.normalized.y * 70);
        }
        _dirctionForMovvingPlayer = _directionfor / 70;

        _mark.transform.position = _startPositionMark + _directionfor;
    }
}
