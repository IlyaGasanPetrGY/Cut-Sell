using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BgMarkerController : MonoBehaviour
{
    [SerializeField] private GameObject _bgMarker;
    private void Update()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began)
            {
                _bgMarker.gameObject.SetActive(true);
                _bgMarker.transform.position = touch.position;
            }
            if (touch.phase == TouchPhase.Ended)
            {
                _bgMarker.gameObject.SetActive(false);
            }
        }
    }
}
