using UnityEngine;
using DG.Tweening;
[RequireComponent(typeof(SphereCollider))]
public class PackageGrassController : MonoBehaviour
{
    private PackageGrassController _packController;
    private SphereCollider _sphereCollider;
    void Start()
    {
        _packController = GetComponent<PackageGrassController>();
        _sphereCollider = GetComponent<SphereCollider>();
        transform.DOLocalMoveY(1f, 1f).SetLoops(-1,LoopType.Yoyo);
    }
    private void OnTriggerEnter(Collider other)
    {
        PlayerBag bag;
        
        if (other.TryGetComponent<PlayerBag>(out bag))
        {
            if (bag.TryGetGrass())
            {
                _sphereCollider.enabled = false;
                transform.parent.DetachChildren();
                bag.GetGrass(transform);
            }
        }
    }
    
}
