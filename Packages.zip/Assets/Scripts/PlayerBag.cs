using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;


public class PlayerBag : MonoBehaviour
{
    [Header("UI elements")]
    [SerializeField] private Transform _scorePos;
    [SerializeField] private Text _grassPanel;
    //[SerializeField] private TMP_Text _tmpScore;
    [Header("Cost")]
    [SerializeField] private int _countFromOneGrassStack = 1;
    [SerializeField] private int _expOneGrass = 15;
    [SerializeField] private GameObject _packGrassSender;
    [SerializeField] private int _maxCountGrass = 40;
    [Header("Speed")]
    [SerializeField,Range(0,1)] private float _frequency = 0.5f;
    [SerializeField] private float _maxTimeToSend = 10f;
    private int _countGrass;
    private int _score;
    private static int _goldcount;
    private static Text _scoreCoin;
    public static int GoldCount
    {
        get
        {
            return _goldcount;
        }
    }
    public int CountFromOneGrassStack
    {
        get { return _countFromOneGrassStack; }
    }

    private void Awake()
    {
        _scoreCoin = GameObject.FindGameObjectWithTag("ScoreText").GetComponent<Text>();
    }
    public void GetGrass(Transform _grassTransform)
    {
        StartCoroutine(CollectAnimation(_grassTransform));
    }
    public IEnumerator CollectAnimation(Transform transformPosGrass)
    {
        transformPosGrass.DOPause();
        while (Vector3.Distance(transformPosGrass.position, transform.position) > 0.01f)
        {
            transformPosGrass.position = Vector3.MoveTowards(transformPosGrass.position, transform.position, Time.deltaTime * 5);
            yield return new WaitForSeconds(0.001f);
        }
        GameObject.Destroy(transformPosGrass.gameObject);
        SetScoreOfGrass();
    }
    public bool TryGetGrass()
    {
        if (_countGrass >= 40)
        {
            return false;
        }
        else
        {
            return true;
        }
        
        
    }
    public void SetScoreOfGrass()
    {
        _countGrass += 1;
        _grassPanel.text = _maxCountGrass.ToString() + "/" + _countGrass;
        //_tmpScore.text = _score.ToString();
    }
    public void SetColetedCutGrass()
    {
        _grassPanel.text = _maxCountGrass.ToString() + "/" + _countGrass;
    }

    /*public IEnumerator SenderGrass()
    {
        yield return new WaitForSeconds()
    }*/
    public void Send()
    {
        StartCoroutine(Sending());
    }
    public float TimeToSending()
    {
        if (_countGrass > 0)
        {
            return (float)_countGrass / (float)_maxCountGrass * (float)_maxTimeToSend;
        }
        else
        {
            return 0;
        }
    }
    public IEnumerator Sending()
    {
        _frequency =(float)TimeToSending()/(float)_countGrass;
        for (int i = 0; i < _countGrass; i++)
        {
            Instantiate(_packGrassSender, transform);
            yield return new WaitForSeconds(_frequency);
        }
        _countGrass = 0;
        SetColetedCutGrass();
    }
    public static void GoldGetting()
    {
        _goldcount += 30;
        _scoreCoin.text = PlayerBag.GoldCount.ToString();
    }
}
