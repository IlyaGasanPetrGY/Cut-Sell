using System.Collections;
using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;

public class GoldController : MonoBehaviour
{
    [SerializeField, Range(1,10) ] private float _controllerSpeedCoin = 10f;
    private GameObject _scorePos;

    private IEnumerator MovvingGold()
    {
        transform.DOScale(new Vector3(0.1f , 0.1f, 0.1f), 4f); 
        while (!Mathf.Equals(transform.position, _scorePos.transform.position))
        {
            Debug.Log("okay");
            yield return new WaitForSeconds(0.001f);
            transform.position = Vector3.MoveTowards(transform.position, _scorePos.transform.position, Time.deltaTime * _controllerSpeedCoin);
        }
        Destroy(gameObject);
        PlayerBag.GoldGetting();
    }
    private void Start()
    {
        transform.parent = null;

        _scorePos = GameObject.FindGameObjectWithTag("Score");
        StartCoroutine(MovvingGold());
        
    }
}
