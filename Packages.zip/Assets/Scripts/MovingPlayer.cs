using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(CapsuleCollider), typeof(Animator))]
[RequireComponent(typeof(PlayerBag))]

public class MovingPlayer : MonoBehaviour
{
    [SerializeField] private Rigidbody _rb;
    [SerializeField] private Animator _anim;
    [SerializeField] private float speed;
    [SerializeField] private MarkerController _marker;


    private const string _attackAnim = "Sword";
    private const string _velocityAnim = "velocity"; 
    private bool _readyToMove = true;
    private Grasscontroller _controlableGrass;
    private PlayerBag _playerBag;
    private const float _timeToCat = 3f;
    private float _timeToSend = 5f;
    private void Start()
    {
        _rb = GetComponent<Rigidbody>();
        _anim = GetComponent<Animator>();
        _playerBag = GetComponent<PlayerBag>();
    }
    
    private void Update()
    {
        ControllerAnimations();
    }
    public void AnimationAtack()
    {
        _rb.velocity = new Vector3(0,0,0);
        _readyToMove = false;
        _anim.SetTrigger(_attackAnim);
        StartCoroutine(SetReadyToMoveTrue(_timeToCat));
    }
    public void StartSending()
    {
        _readyToMove = false;
        SenderGrass();
        //StartCoroutine(SetReadyToMoveTrue(_timeToSend));
        _playerBag.Send();
    }
    private IEnumerator SetReadyToMoveTrue(float timeToMove)
    {
        _rb.velocity = new Vector3(0, 0, 0);
        yield return new WaitForSeconds(timeToMove);
        _readyToMove = true;
    }
    public void SenderGrass()
    {
        _rb.velocity = new Vector3(0, 0, 0);
        _readyToMove = false;
        _timeToSend = _playerBag.TimeToSending();
        Debug.Log(_timeToSend);
        StartCoroutine(SetReadyToMoveTrue(_timeToSend));
    }
    private void ControllerAnimations()
    {
        _anim.SetFloat(_velocityAnim, _rb.velocity.magnitude);
    }
    private void FixedUpdate()
    {
        if (_readyToMove)
        {
            _rb.velocity = new Vector3(_marker.DirctionForMovvingPlayer.x * speed, _rb.velocity.y, _marker.DirctionForMovvingPlayer.y * speed);

            if (_marker.DirctionForMovvingPlayer.x != 0 || _marker.DirctionForMovvingPlayer.y != 0)
            {
                transform.rotation = Quaternion.LookRotation(_rb.velocity);
            }
        }
        
    }
    
   
}
